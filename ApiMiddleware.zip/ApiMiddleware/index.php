<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';
require './entidades/Log.php';

$config['displayErrorDetails']= true;
$config['addContentLengthHeader']= false;

$app = new \Slim\App(["settings"=>$config]);
//primera capa
$app->add(\log::class . ":CrearToken");
//$app->add(\log::class . ":MostrarIntancia");

$app->group('/',function(){

    $this->get('[/]',function(Request $request, Response $response){
        return $response->getBody()->write(" en el grupo");
    })/*->add(\log::class . ":MostrarIntancia")*/;

})->add(\log::class . ":MostrarIntancia");

$app->run();