<?php
use \Firebase\JWT\JWT;
class log 
{
    public $ruta;
    public $metodo;
    public $ip;
    public $fecha;

    public function MostrarIntancia($request,$response,$next)
    {   //recibo los datos desde un metodo get
        $clave  =  $request->getQueryParams();
        //$response->getBody()->write('Desde el metodo instanciador');
        var_dump($clave);
        if(strcasecmp($clave['clave'],"0000")!=0)
        {
            //si esta todo mal quiero que se ejecute este cofigo
            $response->getBody()->write('error el metodo instanciador');
        }
        else
        {
           //si esta todo ok quiero que se ejecute este codigo
            return $next($request,$response);
        }
       
    }
    public function CrearToken($request,$response,$next)
    {
        $datos =$request->getParsedBody();
       $time = time();

        $playLoad =  array(
            'iat'=> $time,
            'exp'=>$time+(30),
            'data'=>$datos,
            'app'=>"primer token php"
        );

        $token = JWT::encode($playLoad,$datos['miclave']);

        return $response->withJson($token,200);
    }
    public function ValidarToken($request,$response,$next)
    {
      $ArrayParametros = $request->getParseBody();
      $token = $ArrayParametros['token'];
      if(empty($token) ||  $token === "")
      {
          throw new Exception("Error Processing Token");
      }
      try {
          $decodificado= JWT::decode(
              $token,
              "miclave",
              ['HS256']
        );
          
      } catch (Exception $e) {
          throw new Exception("Error token  no valido". $e->getMessage());
      }
      return "todo ok!!!";
    }
}
